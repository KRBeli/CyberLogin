package com.mycompany.cyberlogin;

public class Pessoa {
    private int codigo;
    private String nome;
    private String fone;
    private String email;

    //getters//setters
}
